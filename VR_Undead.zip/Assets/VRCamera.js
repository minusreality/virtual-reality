private var controller : CharacterController;
var velocity : Vector3;

function Start()
{
	//controller = GetComponent(CharacterController);		
	//controller.collisionFlags = CollisionFlags.None; // Do not slide on collisions, sliding will move the world relative to the camera. Also there should be no friction
}


function Update () {
}
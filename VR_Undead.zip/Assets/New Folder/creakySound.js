function OnCollisionEnter (other : Collision) {

audio.Play();

}

function OnCollisionExit (other : Collision) {

audio.Stop();

}
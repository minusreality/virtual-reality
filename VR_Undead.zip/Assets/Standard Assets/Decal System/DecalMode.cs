/*
Copyright (c) 2010, Raphael Lopes Baldi & Aquiris Game Experience LTDA.

See the document "TERMS OF USE" included in the project folder for licencing details.
*/

public enum DecalMode
{
	MESH_COLLIDER,
	MESH_FILTER
}
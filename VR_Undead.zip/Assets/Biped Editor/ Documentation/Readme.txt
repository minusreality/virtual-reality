Biped Editor 1.03 readme
=================
More and up to date information available on http://adammechtley.com

Installing Biped Editor
-----------------

Simply import the package and everything should "just work." Watch my video
tutorial online at http://www.youtube.com/watch?v=4IVxuXqFnCE to get an
overview of all of the high-level features and usage of the Biped Editor.

Because you also have full source code with this tool, you can deck it out to
work with all of your weird corner cases, too, if you don't like my automated
processes. Have fun!
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(SteerForCohesion))]
public class SteerForCohesionEditor: SteerForNeighborsEditor {

}

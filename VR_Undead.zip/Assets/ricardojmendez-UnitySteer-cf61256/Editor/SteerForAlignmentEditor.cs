using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(SteerForAlignment))]
public class SteerForAlignmentEditor: SteerForNeighborsEditor {

}

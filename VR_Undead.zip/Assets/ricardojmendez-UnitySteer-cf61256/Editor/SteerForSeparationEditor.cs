using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(SteerForSeparation))]
public class SteerForSeparationEditor: SteerForNeighborsEditor {

}

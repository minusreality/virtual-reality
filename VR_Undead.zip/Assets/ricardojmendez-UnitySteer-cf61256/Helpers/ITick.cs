using System;
namespace UnitySteer.Helpers
{
	public interface ITick
	{
		Tick Tick  { get; }
	}
}

